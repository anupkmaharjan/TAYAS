<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" >
	<head>
		<title>Tayas Confectionery | Chocolate | Compound Chocolate | Sugar</title>
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
		<meta name="description" content="1965 Yılında Konya şehrinde küçük bir imalathanede başlayan ticari öykümüz 1991 yılında Gebze-Kocaeli` ndeki modern tesislerimize taşınmamızla devam etmektedir." />
		<meta name="keywords" content="Şekerleme-Confectionery, Şeker-Candy, Çikolata-Chocolate, Kokolin-Compound Chocolate, Tayaş-Tayas, Kazım Taycı-Kazim Tayci, Şevket Taycı-Sevket Tayci, ACTİON MAX, JOYTOP, ALMOND, KİDDİES KANDY BAR, SHOX BAR, MAGİC ASSORTMENT, BY CHOCO, MALDİNİ, BY FRUİT, MAXTAT, BY MİLK, MİNİ DAMLA, CRİMERA, MİNİYUM, ÇİKOKREM, MİSLEY, ÇOKOMİN, MİXBON, DALE, ONİX, DAMLA, ORİENT, FESTİVAL, PARSİ, FRUTTİNO, PİCCOLO, FRUTTY, PLANET, GİFT, SOFT MİLK, HAMLET, TAYBON, HARMONY, TUVANA, JELMİX" />
		<meta name="googlebot" content="All, Index, Follow" />
		<meta name="Robots" content="All, Index, Follow" />
		<meta name="rating" content="General" />
		<meta name="revisit-after" content="1 days" />
		<meta name="distribution" content="global" />
		<meta name="abstract" content="Şekerleme-Confectionery, Şeker-Candy, Çikolata-Chocolate, Kokolin-Compound Chocolate, Tayaş-Tayas, Kazım Taycı-Kazim Tayci, Şevket Taycı-Sevket Tayci, ACTİON MAX, JOYTOP, ALMOND, KİDDİES KANDY BAR, SHOX BAR, MAGİC ASSORTMENT, BY CHOCO, MALDİNİ, BY FRUİT, MAXTAT, BY MİLK, MİNİ DAMLA, CRİMERA, MİNİYUM, ÇİKOKREM, MİSLEY, ÇOKOMİN, MİXBON, DALE, ONİX, DAMLA, ORİENT, FESTİVAL, PARSİ, FRUTTİNO, PİCCOLO, FRUTTY, PLANET, GİFT, SOFT MİLK, HAMLET, TAYBON, HARMONY, TUVANA, JELMİX" />
		<link href="css/style.css" rel="stylesheet" type="text/css" />
		<link href="css/lightbox.css" rel="stylesheet" />

		<script language="javascript">
			AC_FL_RunContent = 0;
		</script>
		<script src="AC_RunActiveContent.js" language="javascript"></script>
		<script src="js/jquery-1.10.2.min.js"></script>
		<script src="js/lightbox-2.6.min.js"></script>
		<script type="text/javascript" src="Include/stmenu.js"></script>

		</script>
	</head>

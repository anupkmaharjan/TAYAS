<?php
	include "includes/head.php";
?>

<body>
<div id="wrapperic">
<?php
	include "includes/headerSec.php";
?>
<div id="kurumsalorta">
        CEO Message</div>
        
        <div id="content">
        <div class="clear"></div>
				<img src="images/baskn_20090817_134603.jpg" align="left" alt="Tayaş - Başkanın Mesajı" style="padding-right:10px;"><p><span style="font-family: trebuchet ms,geneva; font-size: small;">&nbsp;&nbsp;&nbsp;&nbsp; In nowadays circumstances becoming a brand name requires possessing many factors at once. For example, when we look back, each company`s ultimate goal was to be able to produce high volumes. Every new product would sell as long as it had the right price within its own classification. This chain would continue with the turnover from sales. This basic chain reaction went through a change within the years and became more complex. While in earlier times "high volume production" would represent the most valuable asset of a company, today "high quality production" stands out as the most important asset. It is very hard to catch up with this rapid change that is now replaced by the term "innovation", bringing it to a more valuable level. In today`s circumstances, not only&nbsp;high capacity, high quality and innovation but also communication, that is awareness of your performance plays an important role. No matter how satisfactory, how innovative or high class&nbsp;the products are, not being able to communicate these to the consumers has a negative effect on the dynamism of the producer.</span></p>
<p><span style="font-family: Trebuchet MS; font-size: small;">As Tayas Food, apart from producing high capacity high class products, innovative changes have enabled us&nbsp;to export today to 110 countries. With these values that we apply without compromise, we are now restructuring&nbsp;nationally. Especially with our qualitative and innovative values we are taking serious steps towards becoming a "valuable brand". It is one of our greatest goals to become a trademark nationally as well, as we have already achieved this internationally.</span></p>
<p><span style="font-family: Trebuchet MS; font-size: small;">We are meeting our consumers&nbsp;as a dependable, high quality and innovative company in familiar harmony with our staff. During our 42 years of experience we have learned these concepts very well. The most important lesson I&nbsp;received&nbsp;from my very valuable tutors, my father, our Chairman of the Board Mr. Sevket Tayci, and my grandfather Haci Kazim Tayci is, that the biggest asset is to be dependable.&nbsp;Observing that the&nbsp;term trust, which was&nbsp;the major fundamental concept at the foundation of&nbsp;Tayas Food almost half a century ago, plays a more and more important role within time, this shows that&nbsp;Tayas Food&nbsp;was years ago build on very strong grounds.</span></p>
<p><span style="font-family: Trebuchet MS; font-size: small;">We are a very big family with our staff of 800 people and this family is growing day by day rapidly with our&nbsp;key sentence&nbsp;that we have been emphasizing for years;</span></p>
<p><span style="font-family: Trebuchet MS; font-size: small;">"We have always been producing the best and will continue to do so."</span></p>
<p>&nbsp;</p>
<p><span style="font-family: trebuchet ms,geneva; font-size: small;"><strong>&nbsp;Kazım Taycı</strong></span></p>
<p><span style="font-family: trebuchet ms,geneva; font-size: small;"><strong>&nbsp;General Manager</strong></span></p>
    	</div>
    
   
<?php
	include "includes/footerSec.php";
?>

</body>
</html>
<?php
	include "includes/head.php";
?>

<body>
<div id="wrapperic">
<?php
	include "includes/headerSec.php";
?>
<div id="aramaorta">Products</div>
<div id="content">
  <div class="clear"></div>
  <div id="urunleft">
    <?php
		include "includes/sideproduct.php";
	?>
    <div id="urunkatalt"></div>
  </div>
  <div id="urunicerik">
    <div style="float:left; width:656px;">
      <table border="0" cellspacing="0" cellpadding="0" align="center">
        <tr>
          <td><a href="subcategory.php" title="CANDIES"><img src="images/products/seker_eng_20090930_094649.jpg"/></a></td>
          <td><a href="subcategory.php" title="COMPOUND CHOCOLATES"><img src="images/products/kokolin_eng_20090930_094701.jpg"/></a></td>
        </tr>
        
          <td><a href="subcategory.php" title="CHOCOLATES"><img src="images/products/cikolata_eng_20090930_094717.jpg"/></a></td>
          <td><a href="subcategory.php" title="SPREAD CHOCOLATES"><img src="images/products/krem_eng_20090930_094730.jpg"/></a></td>
        </tr>
      </table>
    </div>
  </div>
</div>
<?php
	include "includes/footerSec.php";
?>

</body>
</html>
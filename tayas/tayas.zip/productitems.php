<?php
include "includes/head.php";
?>

<body>
	<div id="wrapperic">
		<?php
		include "includes/headerSec.php";
		?>
		<div id="aramaorta">
			Products
		</div>

		<div id="content">
			<div class="clear"></div>
			<div id="urunleft">
				<?php
				include "includes/sideproduct.php";
				?>
				<div id="urunkatalt"></div>
			</div>
			<div id="urunicerik">

				<h2>Products / CANDIES / Soft Candies With Filling / Damla</h2>
				<div class="clear"></div>
				<hr />
				<div class="clear"></div>

				<div style="width:600px;">

					<table width="100%" border="0" cellspacing="0" cellpadding="0">
						<tr>

							<td>
							<table border="0" cellspacing="0" cellpadding="0">
								<tr>
									<td><img src="images/tablo_ust.jpg" width="307" height="27" /></td>
								</tr>
								<tr>
									<td background="images/tablo_orta.jpg">
									<table width="90%" border="0" align="center" cellpadding="0" cellspacing="0">
										<tr>
											<td width="100">
											<div align="center">

												<a href="images/products/damlanew1kgbyk_20121107_155310.bmp" rel="lightbox[roadtrip]" title="Damla NEW 2 Bag 1 Kg (Assorted)"><img src="images/products/damlanew1kgkck_20121107_155132.bmp" width="110" border="0" /></a>

												</span>
											</div></td>
											<td>
											<table width="90%" border="0" align="center" cellpadding="0" cellspacing="0">
												<tr>
													<td colspan="2">
													<div class="urunad" align="center">
														<div align="left">
															Damla NEW 2 Bag 1 Kg (Assorted)
														</div>
													</div></td>
												</tr>
												<tr>
													<td colspan="2" height="5"></td>
												</tr>
												<tr>
													<td colspan="2"><strong>Code:</strong> 5567
													<br />
													1 Kg x 8
													<br />
													</td>
												</tr>
												<tr>
											<td colspan="2"><strong>Price:</strong>$ 4.00</td>
										</tr>
											</table></td>
										</tr>
									</table></td>
								</tr>
								<tr>
									<td><img src="images/tablo_alt.jpg" width="307" height="37" /></td>
								</tr>
							</table></td>

							<td>
							<table border="0" cellspacing="0" cellpadding="0">
								<tr>
									<td><img src="images/tablo_ust.jpg" width="307" height="27" /></td>
								</tr>
								<tr>
									<td background="images/tablo_orta.jpg">
									<table width="90%" border="0" align="center" cellpadding="0" cellspacing="0">
										<tr>
											<td width="100">
											<div align="center">

												<a href="images/products/damlanew2poset-b_20130222_122646.jpg" rel="lightbox[roadtrip]" title="Damla NEW 2 Bag 500 Gr (Assorted)"><img src="images/products/damlanew2poset-k_20130222_123243.jpg" width="110" border="0" /></a>

												</span>
											</div></td>
											<td>
											<table width="90%" border="0" align="center" cellpadding="0" cellspacing="0">
												<tr>
													<td colspan="2">
													<div class="urunad" align="center">
														<div align="left">
															Damla NEW 2 Bag 500 Gr (Assorted)
														</div>
													</div></td>
												</tr>
												<tr>
													<td colspan="2" height="5"></td>
												</tr>
												<tr>
													<td colspan="2"><strong>Code:</strong> 5574
													<br />
													500 Gr x 12
													<br />
													</td>
												</tr>
												<tr>
											<td colspan="2"><strong>Price:</strong>$ 4.00</td>
										</tr>
											</table></td>
										</tr>
									</table></td>
								</tr>
								<tr>
									<td><img src="images/tablo_alt.jpg" width="307" height="37" /></td>
								</tr>
							</table></td>
						</tr>
						<td>
						<table border="0" cellspacing="0" cellpadding="0">
							<tr>
								<td><img src="images/tablo_ust.jpg" width="307" height="27" /></td>
							</tr>
							<tr>
								<td background="images/tablo_orta.jpg">
								<table width="90%" border="0" align="center" cellpadding="0" cellspacing="0">
									<tr>
										<td width="100">
										<div align="center">

											<a href="images/products/damlanew2500grposetbyk_20121107_163306.bmp" rel="lightbox[roadtrip]" title="Damla NEW 2 Bag 350 Gr (Assorted)"><img src="images/products/damlanew2poset-k_20130222_123437.jpg" width="110" border="0" /></a>

											</span>
										</div></td>
										<td>
										<table width="90%" border="0" align="center" cellpadding="0" cellspacing="0">
											<tr>
												<td colspan="2">
												<div class="urunad" align="center">
													<div align="left">
														Damla NEW 2 Bag 350 Gr (Assorted)
													</div>
												</div></td>
											</tr>
											<tr>
												<td colspan="2" height="5"></td>
											</tr>
											<tr>
												<td colspan="2"><strong>Code:</strong> 5575
												<br />
												350 Gr x 12
												<br />
												</td>
											</tr>
											<tr>
											<td colspan="2"><strong>Price:</strong>$ 4.00</td>
										</tr>
										</table></td>
									</tr>
								</table></td>
							</tr>
							<tr>
								<td><img src="images/tablo_alt.jpg" width="307" height="37" /></td>
							</tr>
						</table></td>

						<td>
						<table border="0" cellspacing="0" cellpadding="0">
							<tr>
								<td><img src="images/tablo_ust.jpg" width="307" height="27" /></td>
							</tr>
							<tr>
								<td background="images/tablo_orta.jpg">
								<table width="90%" border="0" align="center" cellpadding="0" cellspacing="0">
									<tr>
										<td width="100">
										<div align="center">

											<a href="images/products/5568damlanew21kgpvc_20130222_125709.jpg" rel="lightbox[roadtrip]" title="Damla NEW 2 Pvc 1 Kg (Assorted)"><img src="images/products/5568damlanew21kgpvc-k_20130222_125700.jpg" width="110" border="0" /></a>

											</span>
										</div></td>
										<td>
										<table width="90%" border="0" align="center" cellpadding="0" cellspacing="0">
											<tr>
												<td colspan="2">
												<div class="urunad" align="center">
													<div align="left">
														Damla NEW 2 Pvc 1 Kg (Assorted)
													</div>
												</div></td>
											</tr>
											<tr>
												<td colspan="2" height="5"></td>
											</tr>
											<tr>
												<td colspan="2"><strong>Code:</strong> 5568
												<br />
												1 Kg x 8
												<br />
												</td>
											</tr>
											<tr>
											<td colspan="2"><strong>Price:</strong>$ 4.00</td>
										</tr>
										</table></td>
									</tr>
								</table></td>
							</tr>
							<tr>
								<td><img src="images/tablo_alt.jpg" width="307" height="37" /></td>
							</tr>
						</table></td>
						</tr>
						<td>
						<table border="0" cellspacing="0" cellpadding="0">
							<tr>
								<td><img src="images/tablo_ust.jpg" width="307" height="27" /></td>
							</tr>
							<tr>
								<td background="images/tablo_orta.jpg">
								<table width="90%" border="0" align="center" cellpadding="0" cellspacing="0">

									<tr>
										<td width="100">
										<div align="center">

											<a href="images/products/damlanew2posetkavun90g-b_20130222_123917.jpg" rel="lightbox[roadtrip]" title="Damla NEW 2 Bag 90 Gr (Melon-Pineapple)"><img src="images/products/damlanew2posetkavun90g-k_20130222_124702.jpg" width="110" border="0" /></a>

											</span>
										</div></td>
										<td>
										<table width="90%" border="0" align="center" cellpadding="0" cellspacing="0">
											<tr>
												<td colspan="2">
												<div class="urunad" align="center">
													<div align="left">
														Damla NEW 2 Bag 90 Gr (Melon-Pineapple)
													</div>
												</div></td>
											</tr>
											<tr>
												<td colspan="2" height="5"></td>
											</tr>
											<tr>
												<td colspan="2"><strong>Code:</strong> 5572
												<br />
												90 Gr x 24
												<br />
												</td>
											</tr>
											<tr>
											<td colspan="2"><strong>Price:</strong>$ 4.00</td>
										</tr>
										</table></td>
									</tr>
								</table></td>
							</tr>
							<tr>
								<td><img src="images/tablo_alt.jpg" width="307" height="37" /></td>
							</tr>
						</table></td>

						<td>
						<table border="0" cellspacing="0" cellpadding="0">
							<tr>
								<td><img src="images/tablo_ust.jpg" width="307" height="27" /></td>
							</tr>
							<tr>
								<td background="images/tablo_orta.jpg">
								<table width="90%" border="0" align="center" cellpadding="0" cellspacing="0">
									<tr>
										<td width="100">
										<div align="center">

											<a href="images/products/damlanew2posettropikal90g_20130222_124908.jpg" rel="lightbox[roadtrip]" title="Damla NEW 2 Bag 90 Gr (Watermelon-Tropical)"><img src="images/products/damla90grkucuk_20130221_162841.jpg" width="110" border="0" /></a>

											</span>
										</div></td>
										<td>
										<table width="90%" border="0" align="center" cellpadding="0" cellspacing="0">
											<tr>
												<td colspan="2">
												<div class="urunad" align="center">
													<div align="left">
														Damla NEW 2 Bag 90 Gr (Watermelon-Tropical)
													</div>
												</div></td>
											</tr>
											<tr>
												<td colspan="2" height="5"></td>
											</tr>
											<tr>
												<td colspan="2"><strong>Code:</strong> 5571
												<br />
												90 Gr x 24
												<br />
												</td>
											</tr>
											<tr>
											<td colspan="2"><strong>Price:</strong>$ 4.00</td>
										</tr>
										</table></td>
									</tr>
								</table></td>
							</tr>
							<tr>
								<td><img src="images/tablo_alt.jpg" width="307" height="37" /></td>
							</tr>
						</table></td>
						</tr>
						<td>
						<table border="0" cellspacing="0" cellpadding="0">
							<tr>
								<td><img src="images/tablo_ust.jpg" width="307" height="27" /></td>
							</tr>
							<tr>
								<td background="images/tablo_orta.jpg">
								<table width="90%" border="0" align="center" cellpadding="0" cellspacing="0">
									<tr>
										<td width="100">
										<div align="center">

											<a href="images/products/7-b_20090820_185143.jpg" rel="lightbox[roadtrip]" title="Damla Bag 90 Gr (strawberry) "><img src="images/products/7-k_20090820_185136.jpg" width="110" border="0" /></a>

											</span>
										</div></td>
										<td>
										<table width="90%" border="0" align="center" cellpadding="0" cellspacing="0">
											<tr>
												<td colspan="2">
												<div class="urunad" align="center">
													<div align="left">
														Damla Bag 90 Gr (strawberry)
													</div>
												</div></td>
											</tr>
											<tr>
												<td colspan="2" height="5"></td>
											</tr>
											<tr>
												<td colspan="2"><strong>Code:</strong> 5438
												<br />
												90 Gr x 24
												<br />
												</td>
											</tr>
											<tr>
											<td colspan="2"><strong>Price:</strong>$ 4.00</td>
										</tr>
										</table></td>
									</tr>
								</table></td>
							</tr>
							<tr>
								<td><img src="images/tablo_alt.jpg" width="307" height="37" /></td>
							</tr>
						</table></td>

						<td>
						<table border="0" cellspacing="0" cellpadding="0">
							<tr>
								<td><img src="images/tablo_ust.jpg" width="307" height="27" /></td>
							</tr>
							<tr>
								<td background="images/tablo_orta.jpg">
								<table width="90%" border="0" align="center" cellpadding="0" cellspacing="0">
									<tr>
										<td width="100">
										<div align="center">

											<a href="images/products/1-b_20090902_171654.jpg" rel="lightbox[roadtrip]" title="Damla Bag 90 Gr (Orange)"><img src="images/products/1-k_20090902_171648.jpg" width="110" border="0" /></a>

											</span>
										</div></td>
										<td>
										<table width="90%" border="0" align="center" cellpadding="0" cellspacing="0">
											<tr>
												<td colspan="2">
												<div class="urunad" align="center">
													<div align="left">
														Damla Bag 90 Gr (Orange)
													</div>
												</div></td>
											</tr>
											<tr>
												<td colspan="2" height="5"></td>
											</tr>
											<tr>
												<td colspan="2"><strong>Code:</strong> 5437
												<br />
												90 Gr x 24
												<br />
												</td>
											</tr>
											<tr>
											<td colspan="2"><strong>Price:</strong>$ 4.00</td>
										</tr>
										</table></td>
									</tr>
								</table></td>
							</tr>
							<tr>
								<td><img src="images/tablo_alt.jpg" width="307" height="37" /></td>
							</tr>
						</table></td>
						</tr>

					</table>

				</div>
				<div class="clear"></div>

				<br />
				</td>

				<a href="#2" class="text"><b>1&nbsp;</b></a>

				<a href="#2" class="text"><b>2&nbsp;</b></a>

				<a href="#3" class="text"><b>3&nbsp;</b></a>

				<a href="#4" class="text"><b>4&nbsp;</b></a>

				<a href="#Next" class="text">&nbsp;Next >></a>
				| 1. Pages...
				<br />
				<br />
				<input onClick="history.back();" type="button" value="&laquo; Back" class="buton">

			</div>
		</div>
		<?php
		include "includes/footerSec.php";
		?>
</body>
</html>
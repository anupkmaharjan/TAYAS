<?php
	include "includes/head.php";
?>

<body>
<div id="wrapperic">
<?php
	include "includes/headerSec.php";
?>
        
 <div style="background-image:url(images/iletisimres.jpg);	height:117px;	color: #ffffff;	font-size: 30px;	text-decoration:none;	padding-right:30px;	text-align:right; 	line-height:117px;">Contact Information
        </div>
         <div class="clear"></div>
        <div id="content">
    <table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">
      <tr>
        <td width="272" rowspan="2" valign="top"><div id="urunleft">
          <div id="urunkat">
            <div class="baslik">Contact Us</div>
              
            <div class="clear"></div>
                <div class="kategoriler">
                    <div style="line-height:20px; border:1px solid #cccccc; padding-left:10px;"><a href="contact.php" style="color:#FF0000">Contact Information</a></div>
                    <div style="line-height:20px; border:1px solid #cccccc; padding-left:10px;"><a href="bankinfo.php" style="color:#FF0000">Bank Information</a></div>
                        <div style="line-height:20px; border:1px solid #cccccc; padding-left:10px;"><a href="regional.php" style="color:#FF0000">Regional Offices</a></div>
                        <div style="line-height:20px; border:1px solid #cccccc; padding-left:10px;"><a href="info.php" style="color:#FF0000">Information Form</a></div>
                </div>
            </div>
            
          <div id="urunkatalt"></div>
  
      </div></td>
        <td valign="top">&nbsp;</td>
      </tr>
      <tr>
        <td width="1086" valign="top">
<table width="100%" border="0" cellpadding="2" cellspacing="2" class="text">
          <tr>
            <td height="30" colspan="3" bgcolor="#e1e1e1"><span style="font-size:14px; padding-left:5px; font-weight:bold;">Export Area Representatives </span></td>
          </tr>
          <tr>
            <td colspan="3">&nbsp;</td>
          </tr>
          
          <tr>
            <td colspan="3"><span style="font-weight: bold">Balkans & CIS</span></td>
          </tr>
          <tr>
            <td colspan="3">Nebi YILDIRIM</td>
          </tr>
          <tr>
            <td colspan="3" height="5"><table width="100%" border="0" cellspacing="0" cellpadding="0">
                <tr>
                  <td><span style="font-weight: bold">Regional Executive</span><br />
                      <span style="font-weight: bold">Phone: </span>+90 262 646 57 13 - <span style="font-weight: bold"> Fax: </span>+90 262 641 06 90 -<span style="font-weight: bold"> Gsm: </span>+90 541 801 46 69<br />
                      <span style="font-weight: bold"> E-mail: </span><a href="mailto:nebiyildirim@tayas.com.tr">nebiyildirim@tayas.com.tr</a> - <span style="font-weight: bold">Skype: </span>nebiyildirim</td>
                </tr>
            </table></td>
          </tr>
          <tr>
            <td colspan="3" height="5"></td>
          </tr>
          <tr>
            <td colspan="3" bgcolor="#cccccc"></td>
          </tr>
          <tr>
            <td colspan="3" height="5"></td>
          </tr>
          
          <tr>
            <td colspan="3"><span style="font-weight: bold">Far East & South Sea Islands</span></td>
          </tr>
          <tr>
            <td colspan="3">Ali Volkan TELLİ</td>
          </tr>
          <tr>
            <td colspan="3" height="5"><table width="100%" border="0" cellspacing="0" cellpadding="0">
                <tr>
                  <td><span style="font-weight: bold">Regional Executive</span><br />
                      <span style="font-weight: bold">Phone: </span>+90 262 646 57 13  - <span style="font-weight: bold"> Fax: </span>+90 262 641 06 90 -<span style="font-weight: bold"> Gsm: </span>+90 541 801 46 56<br />
                      <span style="font-weight: bold"> E-mail: </span><a href="mailto:alivolkantelli@tayas.com.tr">alivolkantelli@tayas.com.tr</a> - <span style="font-weight: bold">Skype: </span>ali.volkan</td>
                </tr>
            </table></td>
          </tr>
          <tr>
            <td colspan="3" height="5"></td>
          </tr>
          <tr>
            <td colspan="3" bgcolor="#cccccc"></td>
          </tr>
          <tr>
            <td colspan="3" height="5"></td>
          </tr>
          
          <tr>
            <td colspan="3"><span style="font-weight: bold">Europe & Iraq</span></td>
          </tr>
          <tr>
            <td colspan="3">Yunus TAYCI</td>
          </tr>
          <tr>
            <td colspan="3" height="5"><table width="100%" border="0" cellspacing="0" cellpadding="0">
                <tr>
                  <td><span style="font-weight: bold">Regional Executive</span><br />
                      <span style="font-weight: bold">Phone: </span>+90 262 646 57 13 - <span style="font-weight: bold"> Fax: </span>+90 262 641 06 90 -<span style="font-weight: bold"> Gsm: </span><br />
                      <span style="font-weight: bold"> E-mail: </span><a href="mailto:"></a> - <span style="font-weight: bold">Skype: </span></td>
                </tr>
            </table></td>
          </tr>
          <tr>
            <td colspan="3" height="5"></td>
          </tr>
          <tr>
            <td colspan="3" bgcolor="#cccccc"></td>
          </tr>
          <tr>
            <td colspan="3" height="5"></td>
          </tr>
          
          <tr>
            <td colspan="3"><span style="font-weight: bold">Northern Africa & Middle East</span></td>
          </tr>
          <tr>
            <td colspan="3">Habiba ŞENOL</td>
          </tr>
          <tr>
            <td colspan="3" height="5"><table width="100%" border="0" cellspacing="0" cellpadding="0">
                <tr>
                  <td><span style="font-weight: bold">Regional Executive</span><br />
                      <span style="font-weight: bold">Phone: </span>+90 262 646 57 13  - <span style="font-weight: bold"> Fax: </span>+90 262 641 06 90 -<span style="font-weight: bold"> Gsm: </span>+90 541 801 46 28<br />
                      <span style="font-weight: bold"> E-mail: </span><a href="mailto:habibasenol@tayas.com.tr">habibasenol@tayas.com.tr</a> - <span style="font-weight: bold">Skype: </span>houdafafou</td>
                </tr>
            </table></td>
          </tr>
          <tr>
            <td colspan="3" height="5"></td>
          </tr>
          <tr>
            <td colspan="3" bgcolor="#cccccc"></td>
          </tr>
          <tr>
            <td colspan="3" height="5"></td>
          </tr>
          
          <tr>
            <td colspan="3"><span style="font-weight: bold">Africa & South America</span></td>
          </tr>
          <tr>
            <td colspan="3"></td>
          </tr>
          <tr>
            <td colspan="3" height="5"><table width="100%" border="0" cellspacing="0" cellpadding="0">
                <tr>
                  <td><span style="font-weight: bold">Regional Executive</span><br />
                      <span style="font-weight: bold">Phone: </span>+90 262 646 57 13 - <span style="font-weight: bold"> Fax: </span>+90 262 641 06 90 -<span style="font-weight: bold"> Gsm: </span><br />
                      <span style="font-weight: bold"> E-mail: </span><a href="mailto:"></a> - <span style="font-weight: bold">Skype: </span></td>
                </tr>
            </table></td>
          </tr>
          <tr>
            <td colspan="3" height="5"></td>
          </tr>
          <tr>
            <td colspan="3" bgcolor="#cccccc"></td>
          </tr>
          <tr>
            <td colspan="3" height="5"></td>
          </tr>
          
          <tr>
            <td height="30" colspan="3">&nbsp;</td>
          </tr>
          <tr>
            <td height="30" colspan="3" bgcolor="#e1e1e1"><span style="font-size:14px; padding-left:5px; font-weight:bold;">Domestic Regional Offices</span></td>
          </tr>
          <tr>
            <td colspan="3" valign="top"></td>
          </tr>
          
          <tr>
            <td colspan="3"><span style="font-weight: bold">Public Sales General Distributor</span></td>
          </tr>
          <tr>
            <td width="12%"><span style="padding-left:5px; font-weight:bold;">Address</span></td>
            <td width="2%"><span style="font-weight: bold">:</span></td>
            <td width="86%">BOMET MEDİKAL GIDA - Mürsel DEMİREL</td>
          </tr>
          <tr>
            <td><span style="padding-left:5px; font-weight:bold;">Phone</span></td>
            <td><span style="font-weight: bold">:</span></td>
            <td>0216 332 32 54, 0532 300 86 06</td>
          </tr>
          <tr>
            <td><span style="padding-left:5px; font-weight:bold;">Fax</span></td>
            <td><span style="font-weight: bold">:</span></td>
            <td>0216 332 33 55</td>
          </tr>
          <tr>
            <td colspan="3" height="5"></td>
          </tr>
          <tr>
            <td colspan="3" bgcolor="#cccccc"></td>
          </tr>
          <tr>
            <td colspan="3" height="5"></td>
          </tr>
          
          <tr>
            <td colspan="3"><span style="font-weight: bold">Marmara Regional Office </span></td>
          </tr>
          <tr>
            <td width="12%"><span style="padding-left:5px; font-weight:bold;">Address</span></td>
            <td width="2%"><span style="font-weight: bold">:</span></td>
            <td width="86%">Gebze Organize Sanayi, İhsan Dede Caddesi 800 Sokak No:122, Gebze / KOCAELİ</td>
          </tr>
          <tr>
            <td><span style="padding-left:5px; font-weight:bold;">Phone</span></td>
            <td><span style="font-weight: bold">:</span></td>
            <td>0262 646 57 13 (Pbx)</td>
          </tr>
          <tr>
            <td><span style="padding-left:5px; font-weight:bold;">Fax</span></td>
            <td><span style="font-weight: bold">:</span></td>
            <td>0262 641 06 90</td>
          </tr>
          <tr>
            <td colspan="3" height="5"></td>
          </tr>
          <tr>
            <td colspan="3" bgcolor="#cccccc"></td>
          </tr>
          <tr>
            <td colspan="3" height="5"></td>
          </tr>
          
          <tr>
            <td colspan="3"><span style="font-weight: bold">Eastern Black Sea Regional Office </span></td>
          </tr>
          <tr>
            <td width="12%"><span style="padding-left:5px; font-weight:bold;">Address</span></td>
            <td width="2%"><span style="font-weight: bold">:</span></td>
            <td width="86%"></td>
          </tr>
          <tr>
            <td><span style="padding-left:5px; font-weight:bold;">Phone</span></td>
            <td><span style="font-weight: bold">:</span></td>
            <td></td>
          </tr>
          <tr>
            <td><span style="padding-left:5px; font-weight:bold;">Fax</span></td>
            <td><span style="font-weight: bold">:</span></td>
            <td></td>
          </tr>
          <tr>
            <td colspan="3" height="5"></td>
          </tr>
          <tr>
            <td colspan="3" bgcolor="#cccccc"></td>
          </tr>
          <tr>
            <td colspan="3" height="5"></td>
          </tr>
          
          <tr>
            <td colspan="3"><span style="font-weight: bold">East Mediterranean Sea & Southeastern Anatolia Regional Office </span></td>
          </tr>
          <tr>
            <td width="12%"><span style="padding-left:5px; font-weight:bold;">Address</span></td>
            <td width="2%"><span style="font-weight: bold">:</span></td>
            <td width="86%"></td>
          </tr>
          <tr>
            <td><span style="padding-left:5px; font-weight:bold;">Phone</span></td>
            <td><span style="font-weight: bold">:</span></td>
            <td></td>
          </tr>
          <tr>
            <td><span style="padding-left:5px; font-weight:bold;">Fax</span></td>
            <td><span style="font-weight: bold">:</span></td>
            <td></td>
          </tr>
          <tr>
            <td colspan="3" height="5"></td>
          </tr>
          <tr>
            <td colspan="3" bgcolor="#cccccc"></td>
          </tr>
          <tr>
            <td colspan="3" height="5"></td>
          </tr>
          
          <tr>
            <td colspan="3"><span style="font-weight: bold">Central Anatolia Regional Office </span></td>
          </tr>
          <tr>
            <td width="12%"><span style="padding-left:5px; font-weight:bold;">Address</span></td>
            <td width="2%"><span style="font-weight: bold">:</span></td>
            <td width="86%"></td>
          </tr>
          <tr>
            <td><span style="padding-left:5px; font-weight:bold;">Phone</span></td>
            <td><span style="font-weight: bold">:</span></td>
            <td></td>
          </tr>
          <tr>
            <td><span style="padding-left:5px; font-weight:bold;">Fax</span></td>
            <td><span style="font-weight: bold">:</span></td>
            <td></td>
          </tr>
          <tr>
            <td colspan="3" height="5"></td>
          </tr>
          <tr>
            <td colspan="3" bgcolor="#cccccc"></td>
          </tr>
          <tr>
            <td colspan="3" height="5"></td>
          </tr>
          
          <tr>
            <td colspan="3"><span style="font-weight: bold">South Marmara & Aegean Regional Office</span></td>
          </tr>
          <tr>
            <td width="12%"><span style="padding-left:5px; font-weight:bold;">Address</span></td>
            <td width="2%"><span style="font-weight: bold">:</span></td>
            <td width="86%">Gebze Organize Sanayi, İhsan Dede Caddesi 800 Sokak No:122, Gebze / KOCAELİ</td>
          </tr>
          <tr>
            <td><span style="padding-left:5px; font-weight:bold;">Phone</span></td>
            <td><span style="font-weight: bold">:</span></td>
            <td>0262 646 57 13 (Pbx)</td>
          </tr>
          <tr>
            <td><span style="padding-left:5px; font-weight:bold;">Fax</span></td>
            <td><span style="font-weight: bold">:</span></td>
            <td>0262 641 06 90</td>
          </tr>
          <tr>
            <td colspan="3" height="5"></td>
          </tr>
          <tr>
            <td colspan="3" bgcolor="#cccccc"></td>
          </tr>
          <tr>
            <td colspan="3" height="5"></td>
          </tr>
          
        </table>
        </td>
      </tr>
    </table>
   
  </div>    
    <div class="clear"></div>
    
   
<?php
	include "includes/footerSec.php";
?>

</body>
</html>
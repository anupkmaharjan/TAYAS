<?php
	include "includes/head.php";
?>

<body>
<div id="wrapperic">
<?php
	include "includes/headerSec.php";
?>
<div id="aramaorta">Products</div>
        
        <div id="content">
        <div class="clear"></div>
        <div id="urunleft">
          <?php
		include "includes/sideproduct.php";
		?>
            <div id="urunkatalt"></div>
        </div>
        <div id="urunicerik">
	    
            <div style="float:left; width:668px;">
            
			
            
			<h2>Products / CANDIES</h2>
            <hr />            
			
            <div id="markaaltkat">
                <div align="center" style="margin-top:12px;">
                    <div class="resim"><a href="producttype.php" title="Eclairs"><img src="images/products/damlaeclairs_seker_20100222_161534.jpg" alt="Eclairs" /></a></div>
                    <div class="katad"><a href="producttype.php" title="Eclairs"><strong>Eclairs</strong></a></div>
                </div>
            </div>
            
            <div id="markaaltkat">
                <div align="center" style="margin-top:12px;">
                    <div class="resim"><a href="producttype.php" title="Soft Candies With Filling"><img src="images/products/dolguluyumusak_20090820_104442.jpg" alt="Soft Candies With Filling" /></a></div>
                    <div class="katad"><a href="producttype.php" title="Soft Candies With Filling"><strong>Soft Candies With Filling</strong></a></div>
                </div>
            </div>
            
            <div id="markaaltkat">
                <div align="center" style="margin-top:12px;">
                    <div class="resim"><a href="producttype.php" title="Soft Candies"><img src="images/products/toffee_20090820_104453.jpg" alt="Soft Candies" /></a></div>
                    <div class="katad"><a href="producttype.php" title="Soft Candies"><strong>Soft Candies</strong></a></div>
                </div>
            </div>
            </br>
            <div id="markaaltkat">
                <div align="center" style="margin-top:12px;">
                    <div class="resim"><a href="producttype.php" title="Hard Candies"><img src="images/products/sert_20090820_104503.jpg" alt="Hard Candies" /></a></div>
                    <div class="katad"><a href="producttype.php" title="Hard Candies"><strong>Hard Candies</strong></a></div>
                </div>
            </div>
             
             <div class="clear"></div>
            <input onClick="history.back();" type="button" value="� Back" class="buton">
            </div>
        	 
         </div>   
  </div>
<?php
	include "includes/footerSec.php";
?>

</body>
</html>
<?php
	include "includes/head.php";
?>

<body>
<div id="wrapperic">
<?php
	include "includes/headerSec.php";
?>
        
 <div style="background-image:url(images/iletisimres.jpg);	height:117px;	color: #ffffff;	font-size: 30px;	text-decoration:none;	padding-right:30px;	text-align:right; 	line-height:117px;">Contact Information
        </div>
         <div class="clear"></div>
        <div id="content">
    <table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">
      <tr>
        <td width="272" rowspan="2" valign="top"><div id="urunleft">
          <div id="urunkat">
            <div class="baslik">Contact Us</div>
              
            <div class="clear"></div>
                <div class="kategoriler">
                    <div style="line-height:20px; border:1px solid #cccccc; padding-left:10px;"><a href="contact.php" style="color:#FF0000">Contact Information</a></div>
                    <div style="line-height:20px; border:1px solid #cccccc; padding-left:10px;"><a href="bankinfo.php" style="color:#FF0000">Bank Information</a></div>
                        <div style="line-height:20px; border:1px solid #cccccc; padding-left:10px;"><a href="regional.php" style="color:#FF0000">Regional Offices</a></div>
                        <div style="line-height:20px; border:1px solid #cccccc; padding-left:10px;"><a href="info.php" style="color:#FF0000">Information Form</a></div>
                </div>
            </div>
            
          <div id="urunkatalt"></div>
  
      </div></td>
        <td valign="top">&nbsp;</td>
      </tr>
      <tr>
        <td width="1086" valign="top"><table width="98%" border="0" align="center" cellpadding="0" cellspacing="0">
          
          <tr>
            <td><table width="98%" border="0" align="center" cellpadding="0" cellspacing="0">
          
          <tr>
            <td><table width="98%" border="0" align="center" cellpadding="0" cellspacing="0">
              <tr>
                <td height="30" bgcolor="#e1e1e1"><span style="font-size:14px; padding-left:5px; font-weight:bold;">Information Form</span></td>
              </tr>
              <tr>
                <td>&nbsp;</td>
              </tr>
              <tr>
                <td>Filling out the form below and request to us, you can forward complaints and   suggestions.</td>
              </tr>
              <tr>
                <td>&nbsp;</td>
              </tr>
              <tr>
                <td>
                <form name="form1" method="post" action="http://test.grimor.com/automail/send.asp?e=selda@tayas.com&b=http://www.tayas.com&n=www.tayas.com">
                <table width="98%" border="0" align="center" cellpadding="2" cellspacing="2">
                    <tr>
                      <td width="18%" valign="top"><span class="style8" style="font-weight: bold">Name-Surname</span></td>
                      <td width="82%" valign="top"><span class="style8" style="font-weight: bold">
                        <input style="border:1px solid #c0c0c0; font-family:Tahoma; height:20px; font-size: 12px " size="85" name="Ad" />
                      </span></td>
                    </tr>
                    <tr>
                      <td valign="top"><span class="style8" style="font-weight: bold">Phone</span></td>
                      <td valign="top"><span class="style8">
                        <input style="border:1px solid #c0c0c0; font-family:Tahoma; height:20px; font-size: 12px " size="85" name="Telefon" />
                      </span></td>
                    </tr>
                    <tr>
                      <td valign="top"><span class="style8"><span style="font-weight: bold">E-Mail</span><span class="style9"></span></span></td>
                      <td valign="top"><span class="style8"><span class="style9">
                        <input style="border:1px solid #c0c0c0; font-family:Tahoma; height:20px; font-size: 12px " size="85" name="E_Mail" />
                      </span></span></td>
                    </tr>
                    <tr>
                      <td valign="top"><span class="style8"><span style="font-weight: bold">Address</span></span></td>
                      <td valign="top"><span class="style8">
                        <input style="border:1px solid #c0c0c0; font-family:Tahoma; height:20px; font-size: 12px " size="85" name="Adres" />
                      </span></td>
                    </tr>
                    <tr>
                      <td valign="top"><b>Message</b></td>
                      <td valign="top"><textarea style="border:1px solid #c0c0c0; font-family:Tahoma; width:95%;" name="mesaj" rows="6" cols="4"></textarea></td>
                    </tr>
                    <tr>
                      <td>&nbsp;</td>
                      <td><table width="100%" border="0" cellspacing="0" cellpadding="0">
                          <tr>
                            <td width="42%" align="center"><input name="reset" type="reset" value=" Reset " style="border:1px solid #CCCCCC; background-color:#F5F5F5; width:75px;" />
                              &nbsp;&nbsp;&nbsp;&nbsp;
                              <input name="submit" type="submit" value=" Send " style="border:1px solid #CCCCCC; background-color:#F5F5F5; width:75px;" /></td>
                          </tr>
                      </table></td>
                    </tr>
                </table>
                </form>
                
                </td>
              </tr>
            </table></td>
          </tr>
          <tr>
            <td>&nbsp;</td>
          </tr>
          
          
          
        </table></td>
      </tr>
    </table>
   
  </div>    
    <div class="clear"></div>
    
   
<?php
	include "includes/footerSec.php";
?>

</body>
</html>
<?php
	include "includes/head.php";
?>

<body>
<div id="wrapperic">
<?php
	include "includes/headerSec.php";
?>
        
 <div style="background-image:url(images/iletisimres.jpg);	height:117px;	color: #ffffff;	font-size: 30px;	text-decoration:none;	padding-right:30px;	text-align:right; 	line-height:117px;">Contact Information
        </div>
         <div class="clear"></div>
        <div id="content">
    <table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">
      <tr>
        <td width="272" rowspan="2" valign="top"><div id="urunleft">
          <div id="urunkat">
            <div class="baslik">Contact Us</div>
              
            <div class="clear"></div>
                <div class="kategoriler">
                    <div style="line-height:20px; border:1px solid #cccccc; padding-left:10px;"><a href="contact.php" style="color:#FF0000">Contact Information</a></div>
                    <div style="line-height:20px; border:1px solid #cccccc; padding-left:10px;"><a href="bankinfo.php" style="color:#FF0000">Bank Information</a></div>
                        <div style="line-height:20px; border:1px solid #cccccc; padding-left:10px;"><a href="regional.php" style="color:#FF0000">Regional Offices</a></div>
                        <div style="line-height:20px; border:1px solid #cccccc; padding-left:10px;"><a href="info.php" style="color:#FF0000">Information Form</a></div>
                </div>
            </div>
            
          <div id="urunkatalt"></div>
  
      </div></td>
        <td valign="top">&nbsp;</td>
      </tr>
      <tr>
        <td width="1086" valign="top">
<table width="100%" border="0" cellpadding="2" cellspacing="2" class="text">
              <tr>
                <td width="100%" height="30" bgcolor="#e1e1e1">
                <font face="Cambria">
                <span style="font-size:11pt; padding-left:5px; font-weight:bold">
                T. İŞ BANKASI A. Ş.</span></font><p>
                <font face="Cambria">
                <span style="font-size:11pt; padding-left:5px; font-weight:bold">GEBZE TİCARİ 
                ŞB.
</span></font></td>
              </tr>
              <tr>
                <td><p>&nbsp;</p></td>
              </tr>
        
              <tr>
                  <td><font face="Cambria" style="font-size: 11pt">TR02 0006 4000 001<b>2 440</b>0 000<b>1 43</b> TL</font></td>
              </tr>
              <tr>
                  <td><font face="Cambria" style="font-size: 11pt">TR71 0006 4000 002<b>2 440</b>0 000<b>1 57</b> USD</font></td>
              </tr>
              <tr>
                <td><font face="Cambria" style="font-size: 11pt">TR94 0006 4000 002<b>2 440</b>0 0000 
                <b>34</b> EUR</font></td>
              </tr>
              
              <tr>
                <td height="5"></td>
              </tr>
              <tr>
                <td bgcolor="#cccccc"></td>
              </tr>
              <tr>
                <td height="5"></td>
              </tr>
            
            
              <tr>
                <td height="30"><font face="Cambria" style="font-size: 11pt"><strong>Branch Contact Informations ;</strong><br />
                    <br />
                    &nbsp;</font><table border="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="400" cellpadding="0" id="AutoNumber1">
                      <tr>
                        <td width="84">
                        <font face="Cambria" style="font-size: 11pt">Address :</font></td>
                        <td width="316">
                        <font face="Cambria" style="font-size: 11pt">&nbsp;Hacıhalil Mahallesi, Atatürk Caddesi, Num. 
                        :12,</font></td>
                      </tr>
                      <tr>
                        <td width="84">&nbsp;</td>
                        <td width="316">
                        <font face="Cambria" style="font-size: 11pt">&nbsp;41400 Gebze / KOCAELİ.</font></td>
                      </tr>
                      <tr>
                        <td width="84">&nbsp;</td>
                        <td width="316">&nbsp;</td>
                      </tr>
                      <tr>
                        <td width="84">
                        <font face="Cambria" style="font-size: 11pt">Phone :</font></td>
                        <td width="316">
                        <font face="Cambria" style="font-size: 11pt">&nbsp;(262) 
                        781 20 54</font></td>
                      </tr>
                      <tr>
                        <td width="84">
                        <font face="Cambria" style="font-size: 11pt">Fax :</font></td>
                        <td width="316">
                        <font face="Cambria" style="font-size: 11pt">&nbsp;(262) 641 11 34</font></td>
                      </tr>
                      <tr>
                        <td width="84">&nbsp;</td>
                        <td width="316">&nbsp;</td>
                      </tr>
                      <tr>
                        <td width="84">
                        <font face="Cambria" style="font-size: 11pt">Swift :</font></td>
                        <td width="316">
                        <font face="Cambria" style="font-size: 11pt">&nbsp;ISBKTRISXXX</font></td>
                      </tr>
                    </table>
                    <p><font face="Cambria" style="font-size: 11pt"><br />
                    </font></td>
              </tr>
              
              
            </table>
        </td>
      </tr>
    </table>
   
  </div>    
    <div class="clear"></div>
    
   
<?php
	include "includes/footerSec.php";
?>

</body>
</html>
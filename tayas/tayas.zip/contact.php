<?php
	include "includes/head.php";
?>

<body>
<div id="wrapperic">
<?php
	include "includes/headerSec.php";
?>
        
 <div style="background-image:url(images/iletisimres.jpg);	height:117px;	color: #ffffff;	font-size: 30px;	text-decoration:none;	padding-right:30px;	text-align:right; 	line-height:117px;">Contact Information
        </div>
         <div class="clear"></div>
        <div id="content">
    <table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">
      <tr>
        <td width="272" rowspan="2" valign="top"><div id="urunleft">
          <div id="urunkat">
            <div class="baslik">Contact Us</div>
              
            <div class="clear"></div>
                <div class="kategoriler">
                    <div style="line-height:20px; border:1px solid #cccccc; padding-left:10px;"><a href="contact.php" style="color:#FF0000">Contact Information</a></div>
                    <div style="line-height:20px; border:1px solid #cccccc; padding-left:10px;"><a href="bankinfo.php" style="color:#FF0000">Bank Information</a></div>
                        <div style="line-height:20px; border:1px solid #cccccc; padding-left:10px;"><a href="regional.php" style="color:#FF0000">Regional Offices</a></div>
                        <div style="line-height:20px; border:1px solid #cccccc; padding-left:10px;"><a href="info.php" style="color:#FF0000">Information Form</a></div>
                </div>
            </div>
            
          <div id="urunkatalt"></div>
  
      </div></td>
        <td valign="top">&nbsp;</td>
      </tr>
      <tr>
        <td width="1086" valign="top"><table width="98%" border="0" align="center" cellpadding="0" cellspacing="0">
          
          <tr>
            <td><table width="100%" border="0" cellpadding="2" cellspacing="2" class="text">
              
              <tr>
                <td height="30" colspan="3" bgcolor="e1e1e1"><span style="font-size:14px; padding-left:5px; font-weight:bold;">New Head Office Adress</span></td>
              </tr>
              <tr>
                <td colspan="3" valign="top"></td>
              </tr>
              <tr>
                <td width="12%"><span style="padding-left:5px; font-weight:bold;">Address</span></td>
                <td width="2%"><span style="font-weight: bold">:</span></td>
                <td width="86%">Gebze Organize Sanayi, Ihsan Dede Caddesi 800 Sokak No:122, Gebze / Kocaeli - TURKEY</td>
              </tr>
              <tr>
                <td><span style="padding-left:5px; font-weight:bold;">Phone</span></td>
                <td><span style="font-weight: bold">:</span></td>
                <td>+90 262 646 57 13 (pbx)</td>
              </tr>
              <tr>
                <td><span style="padding-left:5px; font-weight:bold;">Fax</span></td>
                <td><span style="font-weight: bold">:</span></td>
                <td>+90 262 641 06 90</td>
              </tr>
              <tr>
                <td><span style="padding-left:5px; font-weight:bold;">E-Mail</span></td>
                <td><span style="font-weight: bold">:</span></td>
                <td><a href="mailto:info@tayas.com.tr" target="_blank">info@tayas.com.tr</a></td>
              </tr>
              <tr>
                <td colspan="3" align="center"></td>
              </tr>
              <tr>
                <td colspan="3" bgcolor="#999999"></td>
              </tr>
              <tr>
                <td colspan="3"></td>
              </tr>
              
            </table></td>
          </tr>
          <tr>
            <td>&nbsp;</td>
          </tr>
          <tr><td align="center"><iframe width="600" height="390" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="http://maps.google.com/maps/ms?msa=0&amp;msid=202126718816686542991.0004a85a027dc5ce8ab8e&amp;ie=UTF8&amp;t=h&amp;ll=40.858811,29.420829&amp;spn=0.012659,0.025706&amp;z=15&amp;output=embed"></iframe><br /><small>Şunu daha büyük bir haritada görüntüle: <a href="http://maps.google.com/maps/ms?msa=0&amp;msid=202126718816686542991.0004a85a027dc5ce8ab8e&amp;ie=UTF8&amp;t=h&amp;ll=40.858811,29.420829&amp;spn=0.012659,0.025706&amp;z=15&amp;source=embed" style="color:#0000FF;text-align:left">Tayaş Gıda </a></small></div></td></tr>
          
          
        </table></td>
      </tr>
    </table>
   
  </div>    
    <div class="clear"></div>
    
   
<?php
	include "includes/footerSec.php";
?>

</body>
</html>
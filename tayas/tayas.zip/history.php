<?php
	include "includes/head.php";
?>

<body>
<div id="wrapperic">
<?php
	include "includes/headerSec.php";
?>
<<div id="kurumsalorta">
        History        </div>
        
<div id="content">
        <div class="clear"></div>
				<img src="images/tarihce_20090817_085444.jpg" align="left" alt="Tayaş - Tarihçe" style="padding-right:10px;"><p><span><span>
<p><span style="font-family: trebuchet ms,geneva; font-size: small;">&nbsp;</span><span style="font-size: small;"><span style="font-family: trebuchet ms,geneva;"><span>Our history began in Konya in 1965 in a small workshop and continues in our modern plant in Gebze-Kocaeli where we moved in 1991.<br />&nbsp; <br />&nbsp;&nbsp;&nbsp; Today, Tayas has become one of the most important producers of compound chocolate, candy and chocolate products in Turkey and worldwide. While achieving great success in international markets, Tayas&nbsp;is able to&nbsp;target different tastes with a product range including more than 250 different varieties.</span>&nbsp;</span></span></p>
<p>
<p><span style="font-family: trebuchet ms,geneva; font-size: small;">&nbsp;&nbsp;&nbsp; Tayas owes its experience in export to the high quality and hygiene control norms that are applied without compromise. Tayas is certified by the Turkish Standards Institute with a Production Adequacy Certificate and is further accredited for compliance with HACCP and ISO 9001:2000 standards.&nbsp;</span></p>
<p><span style="font-family: trebuchet ms,geneva; font-size: small;">&nbsp;&nbsp;&nbsp; With its ability to comply to the strictest food codexes of different countries and performance of detailed food analysis, Tayas makes unconditional customer satisfaction its principle and&nbsp; continues applying this successfully. The "Gold Star Quality" reward given in Geneva-Switzerland in 2000 has proven Tayas` success and strengthened its thrive for perfection.&nbsp;&nbsp;&nbsp;&nbsp;</span></p>
<p><span style="font-family: trebuchet ms,geneva; font-size: small;">&nbsp;&nbsp;&nbsp; One of the main features of Tayas, apart from quality, is continuous development. In line with the Marketing Department, Research &amp; Development as well as Production Development departments play guiding roles for new products, and key roles for the development of existing products.&nbsp;</span></p>
</p>
<p><span style="font-family: trebuchet ms,geneva; font-size: small;">&nbsp;&nbsp;&nbsp; With 33,000 m&sup2; indoor space, Tayas provides work opportunities for 700 people, running a production capacity of 130 tons per day of which 75% are exported to 110 countries worldwide. In the local market, Tayas is not only supplying the chain stores, but has further started to supply the traditional channels through a distribution system.&nbsp;</span></p>
<p>
<p><span style="font-family: trebuchet ms,geneva; font-size: small;">&nbsp;&nbsp;&nbsp; Tayas continues its efforts daily to reach wider crowds with its growing product range, to improve its industry and to work for a sweeter world.<br />&nbsp;&nbsp;&nbsp; <br />&nbsp;&nbsp;&nbsp; With the pride of having always produced the very best, Tayas`s major goal is to continue producing the best.&nbsp;</span></p>
</p>
</span></span></p>
<p>&nbsp;</p>
<p>
<p>&nbsp;</p>
</p>
<p>&nbsp;</p>
    	</div>
    
    <div class="clear"></div>
    
   
<?php
	include "includes/footerSec.php";
?>

</body>
</html>
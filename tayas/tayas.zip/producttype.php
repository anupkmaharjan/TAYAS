<?php
	include "includes/head.php";
?>

<body>
<div id="wrapperic">
<?php
	include "includes/headerSec.php";
?>
<div id="aramaorta">Products</div>
        
        <div id="content">
        <div class="clear"></div>
        <div id="urunleft">
          <?php
		include "includes/sideproduct.php";
		?>
            <div id="urunkatalt"></div>
        </div>
        <div id="urunicerik">
	    
           <div style="width:670px;">            
			
			<h2>Products / CANDIES / Soft Candies With Filling</h2>
            <hr />            
			
            <div id="markaaltkat">
                <div align="center" style="margin-top:12px;">
                <a href="productitems.php" title="Mini Damla"><img src="images/products/mini_damla_20100226_162802.jpg" alt="Mini Damla" /></a>
                </div>
            </div>
            
            <div id="markaaltkat">
                <div align="center" style="margin-top:12px;">
                <a href="productitems.php" title="Damla"><img src="images/products/damla_20090901_155150.jpg" alt="Damla" /></a>
                </div>
            </div>
             
            
            </div>
            <div class="clear"></div>
            <input onClick="history.back();" type="button" value="� Back" class="buton">
			 
         </div>   
  </div>
<?php
	include "includes/footerSec.php";
?>

</body>
</html>